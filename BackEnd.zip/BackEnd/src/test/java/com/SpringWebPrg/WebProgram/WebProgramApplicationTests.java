package com.SpringWebPrg.WebProgram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebProgramApplicationTests {

	@Test
	void contextLoads() {
	}

}
